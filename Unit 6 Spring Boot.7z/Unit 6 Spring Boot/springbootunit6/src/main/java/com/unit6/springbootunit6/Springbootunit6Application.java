package com.unit6.springbootunit6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootunit6Application {

	public static void main(String[] args) {
		SpringApplication.run(Springbootunit6Application.class, args);
	}

}
