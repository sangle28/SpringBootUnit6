package com.unit6.springbootunit6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootunit6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
